﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class minorUpdate1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 7, 28, 11, 58, 9, 720, DateTimeKind.Utc).AddTicks(6176));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 7, 28, 1, 52, 9, 314, DateTimeKind.Utc).AddTicks(3048));
        }
    }
}
