﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class IncorrectLinking : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MenuItemVarients_DiscountCodes_BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropIndex(
                name: "IX_MenuItemVarients_BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropColumn(
                name: "BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 12, 2, 20, 22, 0, 599, DateTimeKind.Utc).AddTicks(5803));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients",
                type: "TEXT",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 12, 2, 20, 18, 14, 773, DateTimeKind.Utc).AddTicks(7705));

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 1,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 2,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 3,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 4,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 5,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 6,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 7,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 8,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 9,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 10,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 11,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 12,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 13,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 14,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 15,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 16,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 17,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 18,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 19,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.CreateIndex(
                name: "IX_MenuItemVarients_BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients",
                column: "BuyXGetYForZDiscountCodeCode");

            migrationBuilder.AddForeignKey(
                name: "FK_MenuItemVarients_DiscountCodes_BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients",
                column: "BuyXGetYForZDiscountCodeCode",
                principalTable: "DiscountCodes",
                principalColumn: "Id");
        }
    }
}
