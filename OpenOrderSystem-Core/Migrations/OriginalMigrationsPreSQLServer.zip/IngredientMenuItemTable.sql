-- Cheese Pizza Ingredients
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (1,15);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (1,17);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (1,20);

-- Pepperoni Pizza Ingredients
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (2,15);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (2,17);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (2,1);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (2,20);

-- Vegie Pizza Ingredients
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (3,15);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (3,17);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (3,7);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (3,8);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (3,9);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (3,10);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (3,20);

-- Hawaiian Pizza Ingredients
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (4,15);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (4,17);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (4,2);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (4,20);

-- BBQ Pizza Ingredients
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (5,15);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (5,17);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (5,20);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (5,6);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (5,18);

-- Meat Pizza Ingredients
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (6,15);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (6,17);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (6,20);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (6,1);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (6,2);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (6,3);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (6,5);

-- Breakfast Pizza Ingredients
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (7,15);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (7,19);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (7,20);
INSERT INTO IngredientMenuItem (MenuItemsId, IngredientsId)
VALUES (7,4);