﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class LinkedDiscountCodeWhiteList : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MenuItemVarients_DiscountCodes_BaseDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropIndex(
                name: "IX_MenuItemVarients_BaseDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropColumn(
                name: "BaseDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.CreateTable(
                name: "BaseDiscountCodeMenuItemVarient",
                columns: table => new
                {
                    DiscountCodesCode = table.Column<string>(type: "TEXT", nullable: false),
                    WhiteListItemsVarientsId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BaseDiscountCodeMenuItemVarient", x => new { x.DiscountCodesCode, x.WhiteListItemsVarientsId });
                    table.ForeignKey(
                        name: "FK_BaseDiscountCodeMenuItemVarient_DiscountCodes_DiscountCodesCode",
                        column: x => x.DiscountCodesCode,
                        principalTable: "DiscountCodes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_BaseDiscountCodeMenuItemVarient_MenuItemVarients_WhiteListItemsVarientsId",
                        column: x => x.WhiteListItemsVarientsId,
                        principalTable: "MenuItemVarients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 12, 1, 2, 1, 16, 236, DateTimeKind.Utc).AddTicks(1019));

            migrationBuilder.CreateIndex(
                name: "IX_BaseDiscountCodeMenuItemVarient_WhiteListItemsVarientsId",
                table: "BaseDiscountCodeMenuItemVarient",
                column: "WhiteListItemsVarientsId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "BaseDiscountCodeMenuItemVarient");

            migrationBuilder.AddColumn<string>(
                name: "BaseDiscountCodeCode",
                table: "MenuItemVarients",
                type: "TEXT",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 12, 1, 1, 18, 48, 310, DateTimeKind.Utc).AddTicks(5356));

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 1,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 2,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 3,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 4,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 5,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 6,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 7,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 8,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 9,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 10,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 11,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 12,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 13,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 14,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 15,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 16,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 17,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 18,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 19,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.CreateIndex(
                name: "IX_MenuItemVarients_BaseDiscountCodeCode",
                table: "MenuItemVarients",
                column: "BaseDiscountCodeCode");

            migrationBuilder.AddForeignKey(
                name: "FK_MenuItemVarients_DiscountCodes_BaseDiscountCodeCode",
                table: "MenuItemVarients",
                column: "BaseDiscountCodeCode",
                principalTable: "DiscountCodes",
                principalColumn: "Id");
        }
    }
}
