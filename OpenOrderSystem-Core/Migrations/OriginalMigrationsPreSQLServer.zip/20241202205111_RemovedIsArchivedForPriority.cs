﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class RemovedIsArchivedForPriority : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "IsArchived",
                table: "ProductCategories",
                newName: "Priority");

            migrationBuilder.RenameColumn(
                name: "IsArchived",
                table: "MenuItems",
                newName: "Priority");

            migrationBuilder.RenameColumn(
                name: "IsArchived",
                table: "IngredientCategories",
                newName: "Priority");

            migrationBuilder.AddColumn<int>(
                name: "Priority",
                table: "MenuItemVarients",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Priority",
                table: "MenuItemVarients");

            migrationBuilder.RenameColumn(
                name: "Priority",
                table: "ProductCategories",
                newName: "IsArchived");

            migrationBuilder.RenameColumn(
                name: "Priority",
                table: "MenuItems",
                newName: "IsArchived");

            migrationBuilder.RenameColumn(
                name: "Priority",
                table: "IngredientCategories",
                newName: "IsArchived");
        }
    }
}
