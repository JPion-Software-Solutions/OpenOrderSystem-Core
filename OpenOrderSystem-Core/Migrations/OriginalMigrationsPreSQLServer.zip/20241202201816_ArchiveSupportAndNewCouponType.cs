﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class ArchiveSupportAndNewCouponType : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsArchived",
                table: "ProductCategories",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<string>(
                name: "BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients",
                type: "TEXT",
                nullable: true);

            migrationBuilder.AddColumn<bool>(
                name: "IsArchived",
                table: "MenuItems",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsArchived",
                table: "IngredientCategories",
                type: "INTEGER",
                nullable: false,
                defaultValue: false);

            migrationBuilder.CreateTable(
                name: "DiscountCodeItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    DiscountId = table.Column<string>(type: "TEXT", nullable: false),
                    MenuItemId = table.Column<int>(type: "INTEGER", nullable: false),
                    VarientFilter = table.Column<string>(type: "TEXT", nullable: true),
                    ItemRelationType = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscountCodeItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_DiscountCodeItems_DiscountCodes_DiscountId",
                        column: x => x.DiscountId,
                        principalTable: "DiscountCodes",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_DiscountCodeItems_MenuItems_MenuItemId",
                        column: x => x.MenuItemId,
                        principalTable: "MenuItems",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 12, 2, 20, 18, 14, 773, DateTimeKind.Utc).AddTicks(7705));

            migrationBuilder.UpdateData(
                table: "IngredientCategories",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "IngredientCategories",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "IngredientCategories",
                keyColumn: "Id",
                keyValue: 3,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "IngredientCategories",
                keyColumn: "Id",
                keyValue: 4,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "IngredientCategories",
                keyColumn: "Id",
                keyValue: 5,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 1,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 2,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 3,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 4,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 5,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 6,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 7,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 8,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 9,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 10,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 11,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 12,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 13,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 14,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 15,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 16,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 17,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 18,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 19,
                column: "BuyXGetYForZDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 3,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 4,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 5,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 6,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 7,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 8,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 9,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "MenuItems",
                keyColumn: "Id",
                keyValue: 10,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "ProductCategories",
                keyColumn: "Id",
                keyValue: 1,
                column: "IsArchived",
                value: false);

            migrationBuilder.UpdateData(
                table: "ProductCategories",
                keyColumn: "Id",
                keyValue: 2,
                column: "IsArchived",
                value: false);

            migrationBuilder.CreateIndex(
                name: "IX_MenuItemVarients_BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients",
                column: "BuyXGetYForZDiscountCodeCode");

            migrationBuilder.CreateIndex(
                name: "IX_DiscountCodeItems_DiscountId",
                table: "DiscountCodeItems",
                column: "DiscountId");

            migrationBuilder.CreateIndex(
                name: "IX_DiscountCodeItems_MenuItemId",
                table: "DiscountCodeItems",
                column: "MenuItemId");

            migrationBuilder.AddForeignKey(
                name: "FK_MenuItemVarients_DiscountCodes_BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients",
                column: "BuyXGetYForZDiscountCodeCode",
                principalTable: "DiscountCodes",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MenuItemVarients_DiscountCodes_BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropTable(
                name: "DiscountCodeItems");

            migrationBuilder.DropIndex(
                name: "IX_MenuItemVarients_BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropColumn(
                name: "IsArchived",
                table: "ProductCategories");

            migrationBuilder.DropColumn(
                name: "BuyXGetYForZDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropColumn(
                name: "IsArchived",
                table: "MenuItems");

            migrationBuilder.DropColumn(
                name: "IsArchived",
                table: "IngredientCategories");

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 12, 1, 2, 1, 16, 236, DateTimeKind.Utc).AddTicks(1019));
        }
    }
}
