﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class addedMoreCouponTypes : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BuyQty",
                table: "DiscountCodes",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "Discount",
                table: "DiscountCodes",
                type: "REAL",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "GetQty",
                table: "DiscountCodes",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "MinimumSpend",
                table: "DiscountCodes",
                type: "REAL",
                nullable: true);

            migrationBuilder.AddColumn<float>(
                name: "PercentDiscountCode_DiscountPercent",
                table: "DiscountCodes",
                type: "REAL",
                nullable: true);

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 12, 1, 1, 18, 48, 310, DateTimeKind.Utc).AddTicks(5356));
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "BuyQty",
                table: "DiscountCodes");

            migrationBuilder.DropColumn(
                name: "Discount",
                table: "DiscountCodes");

            migrationBuilder.DropColumn(
                name: "GetQty",
                table: "DiscountCodes");

            migrationBuilder.DropColumn(
                name: "MinimumSpend",
                table: "DiscountCodes");

            migrationBuilder.DropColumn(
                name: "PercentDiscountCode_DiscountPercent",
                table: "DiscountCodes");

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 11, 30, 19, 33, 18, 343, DateTimeKind.Utc).AddTicks(1613));
        }
    }
}
