﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class addedDiscounts : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "DiscountId",
                table: "Orders",
                type: "TEXT",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "BaseDiscountCodeCode",
                table: "MenuItemVarients",
                type: "TEXT",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "DiscountCodes",
                columns: table => new
                {
                    Id = table.Column<string>(type: "TEXT", maxLength: 20, nullable: false),
                    Name = table.Column<string>(type: "TEXT", maxLength: 40, nullable: false),
                    Redemptions = table.Column<int>(type: "INTEGER", nullable: false),
                    MaxRedemptions = table.Column<int>(type: "INTEGER", nullable: true),
                    Created = table.Column<DateTime>(type: "TEXT", nullable: false),
                    Expiration = table.Column<DateTime>(type: "TEXT", nullable: true),
                    IsArchived = table.Column<bool>(type: "INTEGER", nullable: false),
                    Discriminator = table.Column<string>(type: "TEXT", maxLength: 21, nullable: false),
                    DiscountPercent = table.Column<float>(type: "REAL", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscountCodes", x => x.Id);
                });

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 11, 30, 19, 33, 18, 343, DateTimeKind.Utc).AddTicks(1613));

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 1,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 2,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 3,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 4,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 5,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 6,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 7,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 8,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 9,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 10,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 11,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 12,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 13,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 14,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 15,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 16,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 17,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 18,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 19,
                column: "BaseDiscountCodeCode",
                value: null);

            migrationBuilder.CreateIndex(
                name: "IX_Orders_DiscountId",
                table: "Orders",
                column: "DiscountId");

            migrationBuilder.CreateIndex(
                name: "IX_MenuItemVarients_BaseDiscountCodeCode",
                table: "MenuItemVarients",
                column: "BaseDiscountCodeCode");

            migrationBuilder.AddForeignKey(
                name: "FK_MenuItemVarients_DiscountCodes_BaseDiscountCodeCode",
                table: "MenuItemVarients",
                column: "BaseDiscountCodeCode",
                principalTable: "DiscountCodes",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Orders_DiscountCodes_DiscountId",
                table: "Orders",
                column: "DiscountId",
                principalTable: "DiscountCodes",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_MenuItemVarients_DiscountCodes_BaseDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropForeignKey(
                name: "FK_Orders_DiscountCodes_DiscountId",
                table: "Orders");

            migrationBuilder.DropTable(
                name: "DiscountCodes");

            migrationBuilder.DropIndex(
                name: "IX_Orders_DiscountId",
                table: "Orders");

            migrationBuilder.DropIndex(
                name: "IX_MenuItemVarients_BaseDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.DropColumn(
                name: "DiscountId",
                table: "Orders");

            migrationBuilder.DropColumn(
                name: "BaseDiscountCodeCode",
                table: "MenuItemVarients");

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 7, 28, 11, 58, 9, 720, DateTimeKind.Utc).AddTicks(6176));
        }
    }
}
