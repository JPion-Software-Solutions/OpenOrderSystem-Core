﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class addedMIVUpc : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Upc",
                table: "MenuItemVarients",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 7, 28, 1, 52, 9, 314, DateTimeKind.Utc).AddTicks(3048));

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 1,
                column: "Upc",
                value: "07000");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 2,
                column: "Upc",
                value: "07001");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 3,
                column: "Upc",
                value: "07002");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 4,
                column: "Upc",
                value: "07003");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 5,
                column: "Upc",
                value: "07004");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 6,
                column: "Upc",
                value: "07005");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 7,
                column: "Upc",
                value: "07006");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 8,
                column: "Upc",
                value: "07007");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 9,
                column: "Upc",
                value: "07008");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 10,
                column: "Upc",
                value: "07009");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 11,
                column: "Upc",
                value: "07010");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 12,
                column: "Upc",
                value: "07011");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 13,
                column: "Upc",
                value: "07012");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 14,
                column: "Upc",
                value: "07013");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 15,
                column: "Upc",
                value: "07014");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 16,
                column: "Upc",
                value: "07015");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 17,
                column: "Upc",
                value: "07220");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 18,
                column: "Upc",
                value: "08834");

            migrationBuilder.UpdateData(
                table: "MenuItemVarients",
                keyColumn: "Id",
                keyValue: 19,
                column: "Upc",
                value: "08879");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Upc",
                table: "MenuItemVarients");

            migrationBuilder.UpdateData(
                table: "Customers",
                keyColumn: "Id",
                keyValue: 1,
                column: "CustomerCreated",
                value: new DateTime(2024, 7, 21, 2, 58, 58, 658, DateTimeKind.Utc).AddTicks(5153));
        }
    }
}
