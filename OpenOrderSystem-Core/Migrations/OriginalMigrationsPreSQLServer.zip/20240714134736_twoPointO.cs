﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

#pragma warning disable CA1814 // Prefer jagged arrays over multidimensional

namespace PizzaParty.Migrations
{
    /// <inheritdoc />
    public partial class twoPointO : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "TEXT", nullable: false),
                    Name = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "TEXT", nullable: false),
                    UserName = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "TEXT", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "INTEGER", nullable: false),
                    PasswordHash = table.Column<string>(type: "TEXT", nullable: true),
                    SecurityStamp = table.Column<string>(type: "TEXT", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "TEXT", nullable: true),
                    PhoneNumber = table.Column<string>(type: "TEXT", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "INTEGER", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "TEXT", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "INTEGER", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Customers",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    Phone = table.Column<string>(type: "TEXT", nullable: false),
                    Email = table.Column<string>(type: "TEXT", nullable: false),
                    CustomerCreated = table.Column<DateTime>(type: "TEXT", nullable: false),
                    EmailUpdates = table.Column<bool>(type: "INTEGER", nullable: false),
                    SMSUpdates = table.Column<bool>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Customers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Ingredients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", maxLength: 40, nullable: false),
                    Price = table.Column<float>(type: "REAL", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ingredients", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ProductCategories",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProductCategories", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    RoleId = table.Column<string>(type: "TEXT", nullable: false),
                    ClaimType = table.Column<string>(type: "TEXT", nullable: true),
                    ClaimValue = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    UserId = table.Column<string>(type: "TEXT", nullable: false),
                    ClaimType = table.Column<string>(type: "TEXT", nullable: true),
                    ClaimValue = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "TEXT", nullable: false),
                    ProviderKey = table.Column<string>(type: "TEXT", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "TEXT", nullable: true),
                    UserId = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "TEXT", nullable: false),
                    RoleId = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "TEXT", nullable: false),
                    LoginProvider = table.Column<string>(type: "TEXT", nullable: false),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    Value = table.Column<string>(type: "TEXT", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "ConfirmationCodes",
                columns: table => new
                {
                    Id = table.Column<string>(type: "TEXT", nullable: false),
                    UserId = table.Column<string>(type: "TEXT", nullable: false),
                    Expiration = table.Column<DateTime>(type: "TEXT", nullable: false),
                    Code = table.Column<string>(type: "TEXT", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ConfirmationCodes", x => x.Id);
                    table.ForeignKey(
                        name: "FK_ConfirmationCodes_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Orders",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    OrderPlaced = table.Column<DateTime>(type: "TEXT", nullable: false),
                    OrderInprogress = table.Column<DateTime>(type: "TEXT", nullable: true),
                    OrderReady = table.Column<DateTime>(type: "TEXT", nullable: true),
                    OrderComplete = table.Column<DateTime>(type: "TEXT", nullable: true),
                    MinutesToReady = table.Column<double>(type: "REAL", nullable: false),
                    CustomerId = table.Column<int>(type: "INTEGER", nullable: true),
                    OrderComments = table.Column<string>(type: "TEXT", maxLength: 128, nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Orders", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Orders_Customers_CustomerId",
                        column: x => x.CustomerId,
                        principalTable: "Customers",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "IngredientProductCategory",
                columns: table => new
                {
                    IngredientsId = table.Column<int>(type: "INTEGER", nullable: false),
                    ProductCategoriesId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IngredientProductCategory", x => new { x.IngredientsId, x.ProductCategoriesId });
                    table.ForeignKey(
                        name: "FK_IngredientProductCategory_Ingredients_IngredientsId",
                        column: x => x.IngredientsId,
                        principalTable: "Ingredients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_IngredientProductCategory_ProductCategories_ProductCategoriesId",
                        column: x => x.ProductCategoriesId,
                        principalTable: "ProductCategories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MenuItems",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: false),
                    ImageUrl = table.Column<string>(type: "TEXT", nullable: true),
                    ProductCategoryId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MenuItems", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MenuItems_ProductCategories_ProductCategoryId",
                        column: x => x.ProductCategoryId,
                        principalTable: "ProductCategories",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "IngredientMenuItem",
                columns: table => new
                {
                    IngredientsId = table.Column<int>(type: "INTEGER", nullable: false),
                    MenuItemsId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IngredientMenuItem", x => new { x.IngredientsId, x.MenuItemsId });
                    table.ForeignKey(
                        name: "FK_IngredientMenuItem_Ingredients_IngredientsId",
                        column: x => x.IngredientsId,
                        principalTable: "Ingredients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_IngredientMenuItem_MenuItems_MenuItemsId",
                        column: x => x.MenuItemsId,
                        principalTable: "MenuItems",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "MenuItemVarients",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Descriptor = table.Column<string>(type: "TEXT", maxLength: 12, nullable: false),
                    Price = table.Column<float>(type: "REAL", nullable: false),
                    MenuItemId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_MenuItemVarients", x => x.Id);
                    table.ForeignKey(
                        name: "FK_MenuItemVarients_MenuItems_MenuItemId",
                        column: x => x.MenuItemId,
                        principalTable: "MenuItems",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "OrderLines",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    MenuItemId = table.Column<int>(type: "INTEGER", nullable: false),
                    MenuItemVarient = table.Column<int>(type: "INTEGER", nullable: false),
                    LineComments = table.Column<string>(type: "TEXT", maxLength: 128, nullable: true),
                    OrderId = table.Column<int>(type: "INTEGER", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_OrderLines", x => x.Id);
                    table.ForeignKey(
                        name: "FK_OrderLines_MenuItems_MenuItemId",
                        column: x => x.MenuItemId,
                        principalTable: "MenuItems",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_OrderLines_Orders_OrderId",
                        column: x => x.OrderId,
                        principalTable: "Orders",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "IngredientOrderLine",
                columns: table => new
                {
                    IngredientsId = table.Column<int>(type: "INTEGER", nullable: false),
                    OrderLinesId = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_IngredientOrderLine", x => new { x.IngredientsId, x.OrderLinesId });
                    table.ForeignKey(
                        name: "FK_IngredientOrderLine_Ingredients_IngredientsId",
                        column: x => x.IngredientsId,
                        principalTable: "Ingredients",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_IngredientOrderLine_OrderLines_OrderLinesId",
                        column: x => x.OrderLinesId,
                        principalTable: "OrderLines",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.InsertData(
                table: "Customers",
                columns: new[] { "Id", "CustomerCreated", "Email", "EmailUpdates", "Name", "Phone", "SMSUpdates" },
                values: new object[] { 1, new DateTime(2024, 7, 14, 13, 47, 36, 365, DateTimeKind.Utc).AddTicks(2381), "Schmoe@joe.com", false, "Joe Schmoe", "2318675309", true });

            migrationBuilder.InsertData(
                table: "Ingredients",
                columns: new[] { "Id", "Name", "Price" },
                values: new object[,]
                {
                    { 1, "Pepperoni", 1.5f },
                    { 2, "Ham", 1.5f },
                    { 3, "Italian Sausage", 1.5f },
                    { 4, "Breakfast Sausage", 1.5f },
                    { 5, "Bacon", 1.5f },
                    { 6, "Chicken", 1.5f },
                    { 7, "Black Olives", 1.5f },
                    { 8, "Green Olives", 1.5f },
                    { 9, "Green Peppers", 1.5f },
                    { 10, "Red Onion", 1.5f },
                    { 11, "Pineapple", 1.5f },
                    { 12, "Mushroom", 1.5f },
                    { 13, "Banana Pepper", 1.5f },
                    { 14, "Jalapeno", 1.5f },
                    { 15, "Mozzarella & Muenster Cheese", 1.5f },
                    { 16, "Montery Jack & Cheddar Cheese", 1.5f },
                    { 17, "Traditional Pizza Sauce", 0f },
                    { 18, "Sweet Baby Ray's BBQ Sauce", 1.5f },
                    { 19, "Breakfast Gravy Sauce", 1.5f },
                    { 20, "Regular Crust", 0f },
                    { 21, "Stuffed Crust", 2.5f }
                });

            migrationBuilder.InsertData(
                table: "ProductCategories",
                columns: new[] { "Id", "Description", "Name" },
                values: new object[,]
                {
                    { 1, "Delicious pizzas that you can customize to your heart's content!", "Pizza" },
                    { 2, "Complement your order with one of our delicious sides!", "Sides" }
                });

            migrationBuilder.InsertData(
                table: "MenuItems",
                columns: new[] { "Id", "Description", "ImageUrl", "Name", "ProductCategoryId" },
                values: new object[,]
                {
                    { 1, "Indulge in the simplicity of a classic cheese pizza - a crispy crust, tangy tomato sauce, and melted mozzarella cheese that ooze together to create a mouthwatering slice of pure cheesy deliciousness.", null, "Classic Cheese", 1 },
                    { 2, "Experience the irresistible flavor of a pepperoni pizza - crispy crust, zesty tomato sauce, melty mozzarella cheese, and spicy pepperoni slices that create the perfect combination of savory, tangy, and slightly spicy.", null, "Classic Pepperoni", 1 },
                    { 3, "Savor the goodness of a veggie pizza - crispy crust, tangy tomato sauce, melty mozzarella cheese, and a variety of fresh veggies that create a burst of flavor and nutrition in every bite.", null, "Veggie", 1 },
                    { 4, "Escape to a tropical paradise with a Hawaiian pizza - crispy crust, tangy tomato sauce, melty mozzarella cheese, juicy chunks of pineapple, and savory ham that create a sweet and savory flavor explosion.", null, "Hawaiian Pizza", 1 },
                    { 5, "Indulge in the smoky and sweet flavor of BBQ chicken pizza - crispy crust, tangy tomato sauce, tender chicken, melted mozzarella cheese, and tangy BBQ sauce that create a mouthwatering combination of flavors.", null, "BBQ Chicken Pizza", 1 },
                    { 6, "Get your carnivorous fix with a meat lover's pizza - crispy crust, savory tomato sauce, melty mozzarella cheese, and a hearty combination of pepperoni, sausage, bacon, and other meats that create a bold and flavorful slice.", null, "Meat Lovers Pizza", 1 },
                    { 7, "Experience the ultimate pizza indulgence with a supreme pizza - crispy crust, zesty tomato sauce, melty mozzarella cheese, and a medley of savory toppings like pepperoni, sausage, onions, peppers, and mushrooms that create a flavor explosion in every bite.", null, "VM Supreme Pizza", 1 },
                    { 8, "Rise and shine with a breakfast pizza - a crispy crust, scrambled eggs, crispy bacon, melty cheese, and sometimes even veggies or a drizzle of syrup for a delicious and savory start to your day.", null, "Breakfast Pizza", 1 },
                    { 9, "Cheese bread is a delectable treat - fresh bread dough mixed with gooey melted cheese, sometimes flavored with garlic, herbs, or spices, and baked to golden perfection for a crispy and savory snack.", null, "Cheese Bread", 2 },
                    { 10, "", null, "PARMESAN DOUGH BITES", 2 }
                });

            migrationBuilder.InsertData(
                table: "MenuItemVarients",
                columns: new[] { "Id", "Descriptor", "MenuItemId", "Price" },
                values: new object[,]
                {
                    { 1, "Small", 1, 10.99f },
                    { 2, "Large", 1, 12.99f },
                    { 3, "Small", 2, 11.99f },
                    { 4, "Large", 2, 13.99f },
                    { 5, "Small", 3, 12.99f },
                    { 6, "Large", 3, 16.99f },
                    { 7, "Small", 4, 15.99f },
                    { 8, "Large", 4, 19.99f },
                    { 9, "Small", 5, 14.99f },
                    { 10, "Large", 5, 19.99f },
                    { 11, "Small", 6, 16.99f },
                    { 12, "Large", 6, 20.99f },
                    { 13, "Small", 7, 16.99f },
                    { 14, "Large", 7, 20.99f },
                    { 15, "Small", 8, 16.99f },
                    { 16, "Large", 8, 20.99f },
                    { 17, "Large", 9, 9.99f },
                    { 18, "12 pc", 10, 7.99f },
                    { 19, "24 pc", 10, 9.99f }
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_ConfirmationCodes_UserId",
                table: "ConfirmationCodes",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_IngredientMenuItem_MenuItemsId",
                table: "IngredientMenuItem",
                column: "MenuItemsId");

            migrationBuilder.CreateIndex(
                name: "IX_IngredientOrderLine_OrderLinesId",
                table: "IngredientOrderLine",
                column: "OrderLinesId");

            migrationBuilder.CreateIndex(
                name: "IX_IngredientProductCategory_ProductCategoriesId",
                table: "IngredientProductCategory",
                column: "ProductCategoriesId");

            migrationBuilder.CreateIndex(
                name: "IX_MenuItems_ProductCategoryId",
                table: "MenuItems",
                column: "ProductCategoryId");

            migrationBuilder.CreateIndex(
                name: "IX_MenuItemVarients_MenuItemId",
                table: "MenuItemVarients",
                column: "MenuItemId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderLines_MenuItemId",
                table: "OrderLines",
                column: "MenuItemId");

            migrationBuilder.CreateIndex(
                name: "IX_OrderLines_OrderId",
                table: "OrderLines",
                column: "OrderId");

            migrationBuilder.CreateIndex(
                name: "IX_Orders_CustomerId",
                table: "Orders",
                column: "CustomerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "ConfirmationCodes");

            migrationBuilder.DropTable(
                name: "IngredientMenuItem");

            migrationBuilder.DropTable(
                name: "IngredientOrderLine");

            migrationBuilder.DropTable(
                name: "IngredientProductCategory");

            migrationBuilder.DropTable(
                name: "MenuItemVarients");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "OrderLines");

            migrationBuilder.DropTable(
                name: "Ingredients");

            migrationBuilder.DropTable(
                name: "MenuItems");

            migrationBuilder.DropTable(
                name: "Orders");

            migrationBuilder.DropTable(
                name: "ProductCategories");

            migrationBuilder.DropTable(
                name: "Customers");
        }
    }
}
